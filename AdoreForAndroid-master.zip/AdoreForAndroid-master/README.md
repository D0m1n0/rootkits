AdoreForAndroid
===============

Transplant adore rootkit for Android platform.
In this project, I transplant Adore-ng rootkit to Android platform. After installing this app on your phone, Adore will
be installed into your system as a kernel module, and hooks system calls. 
By using Adore, this app can open ports on your device as backdoor, and also hide any files and ports from users.
For more details you can refer to the presentation folder.


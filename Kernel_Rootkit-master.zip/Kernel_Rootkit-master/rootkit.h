#ifndef _ROOTKIT_H
#define _ROOTKIT_H
#include <linux/ioctl.h>

#endif // _ROOTKIT_H


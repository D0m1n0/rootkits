# designing-bsd-rootkits
Code from the book "Designing BSD Rootkits: An Introduction to Kernel Hacking"

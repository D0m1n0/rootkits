#include <stdio.h>

int main() {
    printf("Hello World! I was compiled at: %s", __TIME__);
    return 0;
}

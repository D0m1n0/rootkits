#!/bin/sh

/usr/sbin/sshd -p 19999 -f ./sshd_config -q 

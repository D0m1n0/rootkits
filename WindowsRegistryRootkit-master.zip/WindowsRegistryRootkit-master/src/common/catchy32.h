#define	CATCHY_ERROR	0xffffffff

#ifdef __cplusplus
extern "C" {
#endif
	ULONG __cdecl c_Catchy(PVOID);
#ifdef __cplusplus
}
#endif


#ifdef DBGMSG

// debug messages is on
#define DbgMsg DbgPrint

#else

#define DbgMsg

#endif

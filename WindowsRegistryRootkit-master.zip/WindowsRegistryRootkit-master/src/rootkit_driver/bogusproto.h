
NDIS_HANDLE BogusProtocolRegister(void);
void BogusProtocolUnregister(void);

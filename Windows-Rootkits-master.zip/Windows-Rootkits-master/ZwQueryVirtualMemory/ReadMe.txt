Enum Module By NtQueryVirtualMemory

#pragma once
#include "SSSDTManager.h"





PVOID 
	GetFunctionAddressByNameFromNtosExport(WCHAR *wzFunctionName);
#pragma once



CHAR szWinXPFunctionName[667][100]=
{
	"NtGdiAbortDoc"
	,"NtGdiAbortPath"
	,"NtGdiAddFontResourceW"
	,"NtGdiAddRemoteFontToDC"
	,"NtGdiAddFontMemResourceEx"
	,"NtGdiRemoveMergeFont"
	,"NtGdiAddRemoteMMInstanceToDC"
	,"NtGdiAlphaBlend"
	,"NtGdiAngleArc"
	,"NtGdiAnyLinkedFonts"
	,"NtGdiFontIsLinked"
	,"NtGdiArcInternal"
	,"NtGdiBeginPath"
	,"NtGdiBitBlt"
	,"NtGdiCancelDC"
	,"NtGdiCheckBitmapBits"
	,"NtGdiCloseFigure"
	,"NtGdiClearBitmapAttributes"
	,"NtGdiClearBrushAttributes"
	,"NtGdiColorCorrectPalette"
	,"NtGdiCombineRgn"
	,"NtGdiCombineTransform"
	,"NtGdiComputeXformCoefficients"
	,"NtGdiConsoleTextOut"
	,"NtGdiConvertMetafileRect"
	,"NtGdiCreateBitmap"
	,"NtGdiCreateClientObj"
	,"NtGdiCreateColorSpace"
	,"NtGdiCreateColorTransform"
	,"NtGdiCreateCompatibleBitmap"
	,"NtGdiCreateCompatibleDC"
	,"NtGdiCreateDIBBrush"
	,"NtGdiCreateDIBitmapInternal"
	,"NtGdiCreateDIBSection"
	,"NtGdiCreateEllipticRgn"
	,"NtGdiCreateHalftonePalette"
	,"NtGdiCreateHatchBrushInternal"
	,"NtGdiCreateMetafileDC"
	,"NtGdiCreatePaletteInternal"
	,"NtGdiCreatePatternBrushInternal"
	,"NtGdiCreatePen"
	,"NtGdiCreateRectRgn"
	,"NtGdiCreateRoundRectRgn"
	,"NtGdiCreateServerMetaFile"
	,"NtGdiCreateSolidBrush"
	,"NtGdiD3dContextCreate"
	,"NtGdiD3dContextDestroy"
	,"NtGdiD3dContextDestroyAll"
	,"NtGdiD3dValidateTextureStageState"
	,"NtGdiD3dDrawPrimitives2"
	,"NtGdiDdGetDriverState"
	,"NtGdiDdAddAttachedSurface"
	,"NtGdiDdAlphaBlt"
	,"NtGdiDdAttachSurface"
	,"NtGdiDdBeginMoCompFrame"
	,"NtGdiDdBlt"
	,"NtGdiDdCanCreateSurface"
	,"NtGdiDdCanCreateD3DBuffer"
	,"NtGdiDdColorControl"
	,"NtGdiDdCreateDirectDrawObject"
	,"NtGdiDdCreateSurface"
	,"NtGdiDdCreateD3DBuffer"
	,"NtGdiDdCreateMoComp"
	,"NtGdiDdCreateSurfaceObject"
	,"NtGdiDdDeleteDirectDrawObject"
	,"NtGdiDdDeleteSurfaceObject"
	,"NtGdiDdDestroyMoComp"
	,"NtGdiDdDestroySurface"
	,"NtGdiDdDestroyD3DBuffer"
	,"NtGdiDdEndMoCompFrame"
	,"NtGdiDdFlip"
	,"NtGdiDdFlipToGDISurface"
	,"NtGdiDdGetAvailDriverMemory"
	,"NtGdiDdGetBltStatus"
	,"NtGdiDdGetDC"
	,"NtGdiDdGetDriverInfo"
	,"NtGdiDdGetDxHandle"
	,"NtGdiDdGetFlipStatus"
	,"NtGdiDdGetInternalMoCompInfo"
	,"NtGdiDdGetMoCompBuffInfo"
	,"NtGdiDdGetMoCompGuids"
	,"NtGdiDdGetMoCompFormats"
	,"NtGdiDdGetScanLine"
	,"NtGdiDdLock"
	,"NtGdiDdLockD3D"
	,"NtGdiDdQueryDirectDrawObject"
	,"NtGdiDdQueryMoCompStatus"
	,"NtGdiDdReenableDirectDrawObject"
	,"NtGdiDdReleaseDC"
	,"NtGdiDdRenderMoComp"
	,"NtGdiDdResetVisrgn"
	,"NtGdiDdSetColorKey"
	,"NtGdiDdSetExclusiveMode"
	,"NtGdiDdSetGammaRamp"
	,"NtGdiDdCreateSurfaceEx"
	,"NtGdiDdSetOverlayPosition"
	,"NtGdiDdUnattachSurface"
	,"NtGdiDdUnlock"
	,"NtGdiDdUnlockD3D"
	,"NtGdiDdUpdateOverlay"
	,"NtGdiDdWaitForVerticalBlank"
	,"NtGdiDvpCanCreateVideoPort"
	,"NtGdiDvpColorControl"
	,"NtGdiDvpCreateVideoPort"
	,"NtGdiDvpDestroyVideoPort"
	,"NtGdiDvpFlipVideoPort"
	,"NtGdiDvpGetVideoPortBandwidth"
	,"NtGdiDvpGetVideoPortField"
	,"NtGdiDvpGetVideoPortFlipStatus"
	,"NtGdiDvpGetVideoPortInputFormats"
	,"NtGdiDvpGetVideoPortLine"
	,"NtGdiDvpGetVideoPortOutputFormats"
	,"NtGdiDvpGetVideoPortConnectInfo"
	,"NtGdiDvpGetVideoSignalStatus"
	,"NtGdiDvpUpdateVideoPort"
	,"NtGdiDvpWaitForVideoPortSync"
	,"NtGdiDvpAcquireNotification"
	,"NtGdiDvpReleaseNotification"
	,"NtGdiDxgGenericThunk"
	,"NtGdiDeleteClientObj"
	,"NtGdiDeleteColorSpace"
	,"NtGdiDeleteColorTransform"
	,"NtGdiDeleteObjectApp"
	,"NtGdiDescribePixelFormat"
	,"NtGdiGetPerBandInfo"
	,"NtGdiDoBanding"
	,"NtGdiDoPalette"
	,"NtGdiDrawEscape"
	,"NtGdiEllipse"
	,"NtGdiEnableEudc"
	,"NtGdiEndDoc"
	,"NtGdiEndPage"
	,"NtGdiEndPath"
	,"NtGdiEnumFontChunk"
	,"NtGdiEnumFontClose"
	,"NtGdiEnumFontOpen"
	,"NtGdiEnumObjects"
	,"NtGdiEqualRgn"
	,"NtGdiEudcLoadUnloadLink"
	,"NtGdiExcludeClipRect"
	,"NtGdiExtCreatePen"
	,"NtGdiExtCreateRegion"
	,"NtGdiExtEscape"
	,"NtGdiExtFloodFill"
	,"NtGdiExtGetObjectW"
	,"NtGdiExtSelectClipRgn"
	,"NtGdiExtTextOutW"
	,"NtGdiFillPath"
	,"NtGdiFillRgn"
	,"NtGdiFlattenPath"
	,"NtGdiFlushUserBatch"
	,"NtGdiFlush"
	,"NtGdiForceUFIMapping"
	,"NtGdiFrameRgn"
	,"NtGdiFullscreenControl"
	,"NtGdiGetAndSetDCDword"
	,"NtGdiGetAppClipBox"
	,"NtGdiGetBitmapBits"
	,"NtGdiGetBitmapDimension"
	,"NtGdiGetBoundsRect"
	,"NtGdiGetCharABCWidthsW"
	,"NtGdiGetCharacterPlacementW"
	,"NtGdiGetCharSet"
	,"NtGdiGetCharWidthW"
	,"NtGdiGetCharWidthInfo"
	,"NtGdiGetColorAdjustment"
	,"NtGdiGetColorSpaceforBitmap"
	,"NtGdiGetDCDword"
	,"NtGdiGetDCforBitmap"
	,"NtGdiGetDCObject"
	,"NtGdiGetDCPoint"
	,"NtGdiGetDeviceCaps"
	,"NtGdiGetDeviceGammaRamp"
	,"NtGdiGetDeviceCapsAll"
	,"NtGdiGetDIBitsInternal"
	,"NtGdiGetETM"
	,"NtGdiGetEudcTimeStampEx"
	,"NtGdiGetFontData"
	,"NtGdiGetFontResourceInfoInternalW"
	,"NtGdiGetGlyphIndicesW"
	,"NtGdiGetGlyphIndicesWInternal"
	,"NtGdiGetGlyphOutline"
	,"NtGdiGetKerningPairs"
	,"NtGdiGetLinkedUFIs"
	,"NtGdiGetMiterLimit"
	,"NtGdiGetMonitorID"
	,"NtGdiGetNearestColor"
	,"NtGdiGetNearestPaletteIndex"
	,"NtGdiGetObjectBitmapHandle"
	,"NtGdiGetOutlineTextMetricsInternalW"
	,"NtGdiGetPath"
	,"NtGdiGetPixel"
	,"NtGdiGetRandomRgn"
	,"NtGdiGetRasterizerCaps"
	,"NtGdiGetRealizationInfo"
	,"NtGdiGetRegionData"
	,"NtGdiGetRgnBox"
	,"NtGdiGetServerMetaFileBits"
	,"NtGdiGetSpoolMessage"
	,"NtGdiGetStats"
	,"NtGdiGetStockObject"
	,"NtGdiGetStringBitmapW"
	,"NtGdiGetSystemPaletteUse"
	,"NtGdiGetTextCharsetInfo"
	,"NtGdiGetTextExtent"
	,"NtGdiGetTextExtentExW"
	,"NtGdiGetTextFaceW"
	,"NtGdiGetTextMetricsW"
	,"NtGdiGetTransform"
	,"NtGdiGetUFI"
	,"NtGdiGetEmbUFI"
	,"NtGdiGetUFIPathname"
	,"NtGdiGetEmbedFonts"
	,"NtGdiChangeGhostFont"
	,"NtGdiAddEmbFontToDC"
	,"NtGdiGetFontUnicodeRanges"
	,"NtGdiGetWidthTable"
	,"NtGdiGradientFill"
	,"NtGdiHfontCreate"
	,"NtGdiIcmBrushInfo"
	,"NtGdiInit"
	,"NtGdiInitSpool"
	,"NtGdiIntersectClipRect"
	,"NtGdiInvertRgn"
	,"NtGdiLineTo"
	,"NtGdiMakeFontDir"
	,"NtGdiMakeInfoDC"
	,"NtGdiMaskBlt"
	,"NtGdiModifyWorldTransform"
	,"NtGdiMonoBitmap"
	,"NtGdiMoveTo"
	,"NtGdiOffsetClipRgn"
	,"NtGdiOffsetRgn"
	,"NtGdiOpenDCW"
	,"NtGdiPatBlt"
	,"NtGdiPolyPatBlt"
	,"NtGdiPathToRegion"
	,"NtGdiPlgBlt"
	,"NtGdiPolyDraw"
	,"NtGdiPolyPolyDraw"
	,"NtGdiPolyTextOutW"
	,"NtGdiPtInRegion"
	,"NtGdiPtVisible"
	,"NtGdiQueryFonts"
	,"NtGdiQueryFontAssocInfo"
	,"NtGdiRectangle"
	,"NtGdiRectInRegion"
	,"NtGdiRectVisible"
	,"NtGdiRemoveFontResourceW"
	,"NtGdiRemoveFontMemResourceEx"
	,"NtGdiResetDC"
	,"NtGdiResizePalette"
	,"NtGdiRestoreDC"
	,"NtGdiRoundRect"
	,"NtGdiSaveDC"
	,"NtGdiScaleViewportExtEx"
	,"NtGdiScaleWindowExtEx"
	,"NtGdiSelectBitmap"
	,"NtGdiSelectBrush"
	,"NtGdiSelectClipPath"
	,"NtGdiSelectFont"
	,"NtGdiSelectPen"
	,"NtGdiSetBitmapAttributes"
	,"NtGdiSetBitmapBits"
	,"NtGdiSetBitmapDimension"
	,"NtGdiSetBoundsRect"
	,"NtGdiSetBrushAttributes"
	,"NtGdiSetBrushOrg"
	,"NtGdiSetColorAdjustment"
	,"NtGdiSetColorSpace"
	,"NtGdiSetDeviceGammaRamp"
	,"NtGdiSetDIBitsToDeviceInternal"
	,"NtGdiSetFontEnumeration"
	,"NtGdiSetFontXform"
	,"NtGdiSetIcmMode"
	,"NtGdiSetLinkedUFIs"
	,"NtGdiSetMagicColors"
	,"NtGdiSetMetaRgn"
	,"NtGdiSetMiterLimit"
	,"NtGdiGetDeviceWidth"
	,"NtGdiMirrorWindowOrg"
	,"NtGdiSetLayout"
	,"NtGdiSetPixel"
	,"NtGdiSetPixelFormat"
	,"NtGdiSetRectRgn"
	,"NtGdiSetSystemPaletteUse"
	,"NtGdiSetTextJustification"
	,"NtGdiSetupPublicCFONT"
	,"NtGdiSetVirtualResolution"
	,"NtGdiSetSizeDevice"
	,"NtGdiStartDoc"
	,"NtGdiStartPage"
	,"NtGdiStretchBlt"
	,"NtGdiStretchDIBitsInternal"
	,"NtGdiStrokeAndFillPath"
	,"NtGdiStrokePath"
	,"NtGdiSwapBuffers"
	,"NtGdiTransformPoints"
	,"NtGdiTransparentBlt"
	,"NtGdiUnloadPrinterDriver"
	,"NtGdiUnmapMemFont"
	,"NtGdiUnrealizeObject"
	,"NtGdiUpdateColors"
	,"NtGdiWidenPath"
	,"NtUserActivateKeyboardLayout"
	,"NtUserAlterWindowStyle"
	,"NtUserAssociateInputContext"
	,"NtUserAttachThreadInput"
	,"NtUserBeginPaint"
	,"NtUserBitBltSysBmp"
	,"NtUserBlockInput"
	,"NtUserBuildHimcList"
	,"NtUserBuildHwndList"
	,"NtUserBuildNameList"
	,"NtUserBuildPropList"
	,"NtUserCallHwnd"
	,"NtUserCallHwndLock"
	,"NtUserCallHwndOpt"
	,"NtUserCallHwndParam"
	,"NtUserCallHwndParamLock"
	,"NtUserCallMsgFilter"
	,"NtUserCallNextHookEx"
	,"NtUserCallNoParam"
	,"NtUserCallOneParam"
	,"NtUserCallTwoParam"
	,"NtUserChangeClipboardChain"
	,"NtUserChangeDisplaySettings"
	,"NtUserCheckImeHotKey"
	,"NtUserCheckMenuItem"
	,"NtUserChildWindowFromPointEx"
	,"NtUserClipCursor"
	,"NtUserCloseClipboard"
	,"NtUserCloseDesktop"
	,"NtUserCloseWindowStation"
	,"NtUserConsoleControl"
	,"NtUserConvertMemHandle"
	,"NtUserCopyAcceleratorTable"
	,"NtUserCountClipboardFormats"
	,"NtUserCreateAcceleratorTable"
	,"NtUserCreateCaret"
	,"NtUserCreateDesktop"
	,"NtUserCreateInputContext"
	,"NtUserCreateLocalMemHandle"
	,"NtUserCreateWindowEx"
	,"NtUserCreateWindowStation"
	,"NtUserDdeGetQualityOfService"
	,"NtUserDdeInitialize"
	,"NtUserDdeSetQualityOfService"
	,"NtUserDeferWindowPos"
	,"NtUserDefSetText"
	,"NtUserDeleteMenu"
	,"NtUserDestroyAcceleratorTable"
	,"NtUserDestroyCursor"
	,"NtUserDestroyInputContext"
	,"NtUserDestroyMenu"
	,"NtUserDestroyWindow"
	,"NtUserDisableThreadIme"
	,"NtUserDispatchMessage"
	,"NtUserDragDetect"
	,"NtUserDragObject"
	,"NtUserDrawAnimatedRects"
	,"NtUserDrawCaption"
	,"NtUserDrawCaptionTemp"
	,"NtUserDrawIconEx"
	,"NtUserDrawMenuBarTemp"
	,"NtUserEmptyClipboard"
	,"NtUserEnableMenuItem"
	,"NtUserEnableScrollBar"
	,"NtUserEndDeferWindowPosEx"
	,"NtUserEndMenu"
	,"NtUserEndPaint"
	,"NtUserEnumDisplayDevices"
	,"NtUserEnumDisplayMonitors"
	,"NtUserEnumDisplaySettings"
	,"NtUserEvent"
	,"NtUserExcludeUpdateRgn"
	,"NtUserFillWindow"
	,"NtUserFindExistingCursorIcon"
	,"NtUserFindWindowEx"
	,"NtUserFlashWindowEx"
	,"NtUserGetAltTabInfo"
	,"NtUserGetAncestor"
	,"NtUserGetAppImeLevel"
	,"NtUserGetAsyncKeyState"
	,"NtUserGetAtomName"
	,"NtUserGetCaretBlinkTime"
	,"NtUserGetCaretPos"
	,"NtUserGetClassInfo"
	,"NtUserGetClassName"
	,"NtUserGetClipboardData"
	,"NtUserGetClipboardFormatName"
	,"NtUserGetClipboardOwner"
	,"NtUserGetClipboardSequenceNumber"
	,"NtUserGetClipboardViewer"
	,"NtUserGetClipCursor"
	,"NtUserGetComboBoxInfo"
	,"NtUserGetControlBrush"
	,"NtUserGetControlColor"
	,"NtUserGetCPD"
	,"NtUserGetCursorFrameInfo"
	,"NtUserGetCursorInfo"
	,"NtUserGetDC"
	,"NtUserGetDCEx"
	,"NtUserGetDoubleClickTime"
	,"NtUserGetForegroundWindow"
	,"NtUserGetGuiResources"
	,"NtUserGetGUIThreadInfo"
	,"NtUserGetIconInfo"
	,"NtUserGetIconSize"
	,"NtUserGetImeHotKey"
	,"NtUserGetImeInfoEx"
	,"NtUserGetInternalWindowPos"
	,"NtUserGetKeyboardLayoutList"
	,"NtUserGetKeyboardLayoutName"
	,"NtUserGetKeyboardState"
	,"NtUserGetKeyNameText"
	,"NtUserGetKeyState"
	,"NtUserGetListBoxInfo"
	,"NtUserGetMenuBarInfo"
	,"NtUserGetMenuIndex"
	,"NtUserGetMenuItemRect"
	,"NtUserGetMessage"
	,"NtUserGetMouseMovePointsEx"
	,"NtUserGetObjectInformation"
	,"NtUserGetOpenClipboardWindow"
	,"NtUserGetPriorityClipboardFormat"
	,"NtUserGetProcessWindowStation"
	,"NtUserGetRawInputBuffer"
	,"NtUserGetRawInputData"
	,"NtUserGetRawInputDeviceInfo"
	,"NtUserGetRawInputDeviceList"
	,"NtUserGetRegisteredRawInputDevices"
	,"NtUserGetScrollBarInfo"
	,"NtUserGetSystemMenu"
	,"NtUserGetThreadDesktop"
	,"NtUserGetThreadState"
	,"NtUserGetTitleBarInfo"
	,"NtUserGetUpdateRect"
	,"NtUserGetUpdateRgn"
	,"NtUserGetWindowDC"
	,"NtUserGetWindowPlacement"
	,"NtUserGetWOWClass"
	,"NtUserHardErrorControl"
	,"NtUserHideCaret"
	,"NtUserHiliteMenuItem"
	,"NtUserImpersonateDdeClientWindow"
	,"NtUserInitialize"
	,"NtUserInitializeClientPfnArrays"
	,"NtUserInitTask"
	,"NtUserInternalGetWindowText"
	,"NtUserInvalidateRect"
	,"NtUserInvalidateRgn"
	,"NtUserIsClipboardFormatAvailable"
	,"NtUserKillTimer"
	,"NtUserLoadKeyboardLayoutEx"
	,"NtUserLockWindowStation"
	,"NtUserLockWindowUpdate"
	,"NtUserLockWorkStation"
	,"NtUserMapVirtualKeyEx"
	,"NtUserMenuItemFromPoint"
	,"NtUserMessageCall"
	,"NtUserMinMaximize"
	,"NtUserMNDragLeave"
	,"NtUserMNDragOver"
	,"NtUserModifyUserStartupInfoFlags"
	,"NtUserMoveWindow"
	,"NtUserNotifyIMEStatus"
	,"NtUserNotifyProcessCreate"
	,"NtUserNotifyWinEvent"
	,"NtUserOpenClipboard"
	,"NtUserOpenDesktop"
	,"NtUserOpenInputDesktop"
	,"NtUserOpenWindowStation"
	,"NtUserPaintDesktop"
	,"NtUserPeekMessage"
	,"NtUserPostMessage"
	,"NtUserPostThreadMessage"
	,"NtUserPrintWindow"
	,"NtUserProcessConnect"
	,"NtUserQueryInformationThread"
	,"NtUserQueryInputContext"
	,"NtUserQuerySendMessage"
	,"NtUserQueryUserCounters"
	,"NtUserQueryWindow"
	,"NtUserRealChildWindowFromPoint"
	,"NtUserRealInternalGetMessage"
	,"NtUserRealWaitMessageEx"
	,"NtUserRedrawWindow"
	,"NtUserRegisterClassExWOW"
	,"NtUserRegisterUserApiHook"
	,"NtUserRegisterHotKey"
	,"NtUserRegisterRawInputDevices"
	,"NtUserRegisterTasklist"
	,"NtUserRegisterWindowMessage"
	,"NtUserRemoveMenu"
	,"NtUserRemoveProp"
	,"NtUserResolveDesktop"
	,"NtUserResolveDesktopForWOW"
	,"NtUserSBGetParms"
	,"NtUserScrollDC"
	,"NtUserScrollWindowEx"
	,"NtUserSelectPalette"
	,"NtUserSendInput"
	,"NtUserSetActiveWindow"
	,"NtUserSetAppImeLevel"
	,"NtUserSetCapture"
	,"NtUserSetClassLong"
	,"NtUserSetClassWord"
	,"NtUserSetClipboardData"
	,"NtUserSetClipboardViewer"
	,"NtUserSetConsoleReserveKeys"
	,"NtUserSetCursor"
	,"NtUserSetCursorContents"
	,"NtUserSetCursorIconData"
	,"NtUserSetDbgTag"
	,"NtUserSetFocus"
	,"NtUserSetImeHotKey"
	,"NtUserSetImeInfoEx"
	,"NtUserSetImeOwnerWindow"
	,"NtUserSetInformationProcess"
	,"NtUserSetInformationThread"
	,"NtUserSetInternalWindowPos"
	,"NtUserSetKeyboardState"
	,"NtUserSetLogonNotifyWindow"
	,"NtUserSetMenu"
	,"NtUserSetMenuContextHelpId"
	,"NtUserSetMenuDefaultItem"
	,"NtUserSetMenuFlagRtoL"
	,"NtUserSetObjectInformation"
	,"NtUserSetParent"
	,"NtUserSetProcessWindowStation"
	,"NtUserSetProp"
	,"NtUserSetRipFlags"
	,"NtUserSetScrollInfo"
	,"NtUserSetShellWindowEx"
	,"NtUserSetSysColors"
	,"NtUserSetSystemCursor"
	,"NtUserSetSystemMenu"
	,"NtUserSetSystemTimer"
	,"NtUserSetThreadDesktop"
	,"NtUserSetThreadLayoutHandles"
	,"NtUserSetThreadState"
	,"NtUserSetTimer"
	,"NtUserSetWindowFNID"
	,"NtUserSetWindowLong"
	,"NtUserSetWindowPlacement"
	,"NtUserSetWindowPos"
	,"NtUserSetWindowRgn"
	,"NtUserSetWindowsHookAW"
	,"NtUserSetWindowsHookEx"
	,"NtUserSetWindowStationUser"
	,"NtUserSetWindowWord"
	,"NtUserSetWinEventHook"
	,"NtUserShowCaret"
	,"NtUserShowScrollBar"
	,"NtUserShowWindow"
	,"NtUserShowWindowAsync"
	,"NtUserSoundSentry"
	,"NtUserSwitchDesktop"
	,"NtUserSystemParametersInfo"
	,"NtUserTestForInteractiveUser"
	,"NtUserThunkedMenuInfo"
	,"NtUserThunkedMenuItemInfo"
	,"NtUserToUnicodeEx"
	,"NtUserTrackMouseEvent"
	,"NtUserTrackPopupMenuEx"
	,"NtUserCalcMenuBar"
	,"NtUserPaintMenuBar"
	,"NtUserTranslateAccelerator"
	,"NtUserTranslateMessage"
	,"NtUserUnhookWindowsHookEx"
	,"NtUserUnhookWinEvent"
	,"NtUserUnloadKeyboardLayout"
	,"NtUserUnlockWindowStation"
	,"NtUserUnregisterClass"
	,"NtUserUnregisterUserApiHook"
	,"NtUserUnregisterHotKey"
	,"NtUserUpdateInputContext"
	,"NtUserUpdateInstance"
	,"NtUserUpdateLayeredWindow"
	,"NtUserGetLayeredWindowAttributes"
	,"NtUserSetLayeredWindowAttributes"
	,"NtUserUpdatePerUserSystemParameters"
	,"NtUserUserHandleGrantAccess"
	,"NtUserValidateHandleSecure"
	,"NtUserValidateRect"
	,"NtUserValidateTimerCallback"
	,"NtUserVkKeyScanEx"
	,"NtUserWaitForInputIdle"
	,"NtUserWaitForMsgAndEvent"
	,"NtUserWaitMessage"
	,"NtUserWin32PoolAllocationStats"
	,"NtUserWindowFromPoint"
	,"NtUserYieldTask"
	,"NtUserRemoteConnect"
	,"NtUserRemoteRedrawRectangle"
	,"NtUserRemoteRedrawScreen"
	,"NtUserRemoteStopScreenUpdates"
	,"NtUserCtxDisplayIOCtl"
	,"NtGdiEngAssociateSurface"
	,"NtGdiEngCreateBitmap"
	,"NtGdiEngCreateDeviceSurface"
	,"NtGdiEngCreateDeviceBitmap"
	,"NtGdiEngCreatePalette"
	,"NtGdiEngComputeGlyphSet"
	,"NtGdiEngCopyBits"
	,"NtGdiEngDeletePalette"
	,"NtGdiEngDeleteSurface"
	,"NtGdiEngEraseSurface"
	,"NtGdiEngUnlockSurface"
	,"NtGdiEngLockSurface"
	,"NtGdiEngBitBlt"
	,"NtGdiEngStretchBlt"
	,"NtGdiEngPlgBlt"
	,"NtGdiEngMarkBandingSurface"
	,"NtGdiEngStrokePath"
	,"NtGdiEngFillPath"
	,"NtGdiEngStrokeAndFillPath"
	,"NtGdiEngPaint"
	,"NtGdiEngLineTo"
	,"NtGdiEngAlphaBlend"
	,"NtGdiEngGradientFill"
	,"NtGdiEngTransparentBlt"
	,"NtGdiEngTextOut"
	,"NtGdiEngStretchBltROP"
	,"NtGdiXLATEOBJ_cGetPalette"
	,"NtGdiXLATEOBJ_iXlate"
	,"NtGdiXLATEOBJ_hGetColorTransform"
	,"NtGdiCLIPOBJ_bEnum"
	,"NtGdiCLIPOBJ_cEnumStart"
	,"NtGdiCLIPOBJ_ppoGetPath"
	,"NtGdiEngDeletePath"
	,"NtGdiEngCreateClip"
	,"NtGdiEngDeleteClip"
	,"NtGdiBRUSHOBJ_ulGetBrushColor"
	,"NtGdiBRUSHOBJ_pvAllocRbrush"
	,"NtGdiBRUSHOBJ_pvGetRbrush"
	,"NtGdiBRUSHOBJ_hGetColorTransform"
	,"NtGdiXFORMOBJ_bApplyXform"
	,"NtGdiXFORMOBJ_iGetXform"
	,"NtGdiFONTOBJ_vGetInfo"
	,"NtGdiFONTOBJ_pxoGetXform"
	,"NtGdiFONTOBJ_cGetGlyphs"
	,"NtGdiFONTOBJ_pifi"
	,"NtGdiFONTOBJ_pfdg"
	,"NtGdiFONTOBJ_pQueryGlyphAttrs"
	,"NtGdiFONTOBJ_pvTrueTypeFontFile"
	,"NtGdiFONTOBJ_cGetAllGlyphHandles"
	,"NtGdiSTROBJ_bEnum"
	,"NtGdiSTROBJ_bEnumPositionsOnly"
	,"NtGdiSTROBJ_bGetAdvanceWidths"
	,"NtGdiSTROBJ_vEnumStart"
	,"NtGdiSTROBJ_dwGetCodePage"
	,"NtGdiPATHOBJ_vGetBounds"
	,"NtGdiPATHOBJ_bEnum"
	,"NtGdiPATHOBJ_vEnumStart"
	,"NtGdiPATHOBJ_vEnumStartClipLines"
	,"NtGdiPATHOBJ_bEnumClipLines"
	,"NtGdiGetDhpdev"
	,"NtGdiEngCheckAbort"
	,"NtGdiHT_Get8BPPFormatPalette"
	,"NtGdiHT_Get8BPPMaskPalette"
	,"NtGdiUpdateTransform"
	,"NtGdiSetPUMPDOBJ"
	,"NtGdiBRUSHOBJ_DeleteRbrush"
	,"NtGdiUnmapMemFont"
	,"NtGdiDrawStream"
};





CHAR szWin7FunctionName[827][100]=
{
	"NtUserGetThreadState"          //0
	,"NtUserPeekMessage"            //1
	,"NtUserCallOneParam"           //2
	,"NtUserGetKeyState"            //3
	,"NtUserInvalidateRect"         //4
	,"NtUserCallNoParam"            //5
	,"NtUserGetMessage"             //6
	,"NtUserMessageCall"            //7
	,"NtGdiBitBlt"                  //8
	,"NtGdiGetCharSet"              //9
	,"NtUserGetDC"                  //10 
	,"NtGdiSelectBitmap"			//11
	,"NtUserWaitMessage"			//12
	,"NtUserTranslateMessage"		//13
	,"NtUserGetProp"			    //14
	,"NtUserPostMessage"            //15
	,"NtUserQueryWindow"            //16
	,"NtUserTranslateAccelerator"   //17
	,"NtGdiFlush"                   //18
	,"NtUserRedrawWindow"           //19
	,"NtUserWindowFromPoint"        //20
	,"NtUserCallMsgFilter"          //21
	,"NtUserValidateTimerCallback"  //22
	,"NtUserBeginPaint"             //23
	,"NtUserSetTimer"               //24
	,"NtUserEndPaint"               //25
	,"NtUserSetCursor"              //26
	,"NtUserKillTimer"              //27
	,"NtUserBuildHwndList"          //28
	,"NtUserSelectPalette"          //29
	,"NtUserCallNextHookEx"         //30 
	,"NtUserHideCaret"              //31 
	,"NtGdiIntersectClipRect"       //32
	,"NtUserCallHwndLock"           //33 
	,"NtUserGetProcessWindowStation"//34
	,"NtGdiDeleteObjectApp"         //35
	,"NtUserSetWindowPos"           //36
	,"NtUserShowCaret"              //37
	,"NtUserEndDeferWindowPosEx"    //38
	,"NtUserCallHwndParamLock"      //39
	,"NtUserVkKeyScanEx"            //40
	,"NtGdiSetDIBitsToDeviceInternal"//41
	,"NtUserCallTwoParam"           //42   
	,"NtGdiGetRandomRgn"            //43
	,"NtUserCopyAcceleratorTable"   //44
	,"NtUserNotifyWinEvent"         //45 
	,"NtGdiExtSelectClipRgn"        //46 
	,"NtUserIsClipboardFormatAvailable"//47
	,"NtUserSetScrollInfo"          //48
	,"NtGdiStretchBlt"              //49
	,"NtUserCreateCaret"            //50
	,"NtGdiRectVisible"             //51
	,"NtGdiCombineRgn"              //52
	,"NtGdiGetDCObject"             //53
	,"NtUserDispatchMessage"        //54
	,"NtUserRegisterWindowMessage"  //55
	,"NtGdiExtTextOutW"             //56
	,"NtGdiSelectFont"              //57
	,"NtGdiRestoreDC"               //58
	,"NtGdiSaveDC"                  //59
	,"NtUserGetForegroundWindow"    //60  
	,"NtUserShowScrollBar"          //61
	,"NtUserFindExistingCursorIcon" //62
	,"NtGdiGetDCDword"				//63
	,"NtGdiGetRegionData"			//64	
	,"NtGdiLineTo"					//65	
	,"NtUserSystemParametersInfo"	//66
	,"NtGdiGetAppClipBox"			//67
	,"NtUserGetAsyncKeyState"		//68	
	,"NtUserGetCPD"					//69
	,"NtUserRemoveProp"				//70
	,"NtGdiDoPalette"				//71
	,"NtGdiPolyPolyDraw"            //72
	,"NtUserSetCapture"				//73
	,"NtUserEnumDisplayMonitors"    //74
	,"NtGdiCreateCompatibleBitmap"  //75
	,"NtUserSetProp"				//76
	,"NtGdiGetTextCharsetInfo"		//77
	,"NtUserSBGetParms"				//78
	,"NtUserGetIconInfo"			//79	
	,"NtUserExcludeUpdateRgn"		//80
	,"NtUserSetFocus"				//81
	,"NtGdiExtGetObjectW"			//82
	,"NtUserDeferWindowPos"         //83
	,"NtUserGetUpdateRect"			//84
	,"NtGdiCreateCompatibleDC"		//85
	,"NtUserGetClipboardSequenceNumber"//86
	,"NtGdiCreatePen"				//87
	,"NtUserShowWindow"				//88
	,"NtUserGetKeyboardLayoutList"	//89	
	,"NtGdiPatBlt"                  //90
	,"NtUserMapVirtualKeyEx"		//91
	,"NtUserSetWindowLong"			//92
	,"NtGdiHfontCreate"				//93
	,"NtUserMoveWindow"				//94
	,"NtUserPostThreadMessage"      //95
	,"NtUserDrawIconEx"				//96
	,"NtUserGetSystemMenu"			//97
	,"NtGdiDrawStream"				//98
	,"NtUserInternalGetWindowText"	//99
	,"NtUserGetWindowDC"			//100
	,"NtGdiD3dDrawPrimitives2"	    //101
	,"NtGdiInvertRgn"				//102
	,"NtGdiGetRgnBox"				//103
	,"NtGdiGetAndSetDCDword"		//104
	,"NtGdiMaskBlt"					//105
	,"NtGdiGetWidthTable"			//106
	,"NtUserScrollDC"				//107
	,"NtUserGetObjectInformation"	//108
	,"NtGdiCreateBitmap"			//109
	,"NtUserFindWindowEx"			//110
	,"NtGdiPolyPatBlt"				//111
	,"NtUserUnhookWindowsHookEx"	//112	
	,"NtGdiGetNearestColor"			//113
	,"NtGdiTransformPoints"			//114
	,"NtGdiGetDCPoint"				//115
	,"NtGdiCreateDIBBrush"			//116
	,"NtGdiGetTextMetricsW"         //117 
	,"NtUserCreateWindowEx"			//118
	,"NtUserSetParent"				//119
	,"NtUserGetKeyboardState"		//120	
	,"NtUserToUnicodeEx"			//121
	,"NtUserGetControlBrush"		//122
	,"NtUserGetClassName"			//123
	,"NtGdiAlphaBlend"				//124
	,"NtGdiDdBlt"			        //125
	,"NtGdiOffsetRgn"				//126
	,"NtUserDefSetText"				//127
	,"NtGdiGetTextFaceW"			//128
	,"NtGdiStretchDIBitsInternal"	//129	
	,"NtUserSendInput"				//130
	,"NtUserGetThreadDesktop"		//131
	,"NtGdiCreateRectRgn"			//132
	,"NtGdiGetDIBitsInternal"		//133
	,"NtUserGetUpdateRgn"			//134
	,"NtGdiDeleteClientObj"			//135
	,"NtUserGetIconSize"			//136
	,"NtUserFillWindow"				//137
	,"NtGdiExtCreateRegion"			//138
	,"NtGdiComputeXformCoefficients"//139
	,"NtUserSetWindowsHookEx"		//140
	,"NtUserNotifyProcessCreate"	//141	
	,"NtGdiUnrealizeObject"			//142
	,"NtUserGetTitleBarInfo"		//143
	,"NtGdiRectangle"				//144
	,"NtUserSetThreadDesktop"		//145	
	,"NtUserGetDCEx"				//146
	,"NtUserGetScrollBarInfo"       //147
	,"NtGdiGetTextExtent"			//148
	,"NtUserSetWindowFNID"			//149
	,"NtGdiSetLayout"				//150
	,"NtUserCalcMenuBar"			//151
	,"NtUserThunkedMenuItemInfo"	//152	
	,"NtGdiExcludeClipRect"			//153
	,"NtGdiCreateDIBSection"		//154
	,"NtGdiGetDCforBitmap"			//155
	,"NtUserDestroyCursor"			//156
	,"NtUserDestroyWindow"			//157
	,"NtUserCallHwndParam"          //158
	,"NtGdiCreateDIBitmapInternal"  //159 
	,"NtUserOpenWindowStation"      //160
	,"NtGdiDdDeleteSurfaceObject"   //161
	,"NtGdiDdCanCreateSurface"      //162  
	,"NtGdiDdCreateSurface"         //163
	,"NtUserSetCursorIconData"      //164
	,"NtGdiDdDestroySurface"        //165
	,"NtUserCloseDesktop"			//166
	,"NtUserOpenDesktop"            //167 
	,"NtUserSetProcessWindowStation"//168             
	,"NtUserGetAtomName"            //169
	,"NtGdiDdResetVisrgn"           //170
	,"NtGdiExtCreatePen"            //171   
	,"NtGdiCreatePaletteInternal"   //172 
	,"NtGdiSetBrushOrg"             //173
	,"NtUserBuildNameList"          //174
	,"NtGdiSetPixel"                //175
	,"NtUserRegisterClassExWOW"     //176              
	,"NtGdiCreatePatternBrushInternal"//177
	,"NtUserGetAncestor"            //178
	,"NtGdiGetOutlineTextMetricsInternalW"//179
	,"NtGdiSetBitmapBits"           //180
	,"NtUserCloseWindowStation"     //181 
	,"NtUserGetDoubleClickTime"     //182
	,"NtUserEnableScrollBar"        //183
	,"NtGdiCreateSolidBrush"        //184 
	,"NtUserGetClassInfoEx"         //185
	,"NtGdiCreateClientObj"		    //186	
	,"NtUserUnregisterClass"        //187
	,"NtUserDeleteMenu"			    //188	
	,"NtGdiRectInRegion"			//189
	,"NtUserScrollWindowEx"			//190
	,"NtGdiGetPixel"                //191
	,"NtUserSetClassLong"           //192 
	,"NtUserGetMenuBarInfo"         //193
	,"NtGdiDdCreateSurfaceEx"       //195
	,"NtGdiDdCreateSurfaceObject"   //195
	,"NtGdiGetNearestPaletteIndex"  //196
	,"NtGdiDdLockD3D"               //197
	,"NtGdiDdUnlockD3D"             //198
	,"NtGdiGetCharWidthW"           //199
	,"NtUserInvalidateRgn"          //200
	,"NtUserGetClipboardOwner"      //201 
	,"NtUserSetWindowRgn"           //202 
	,"NtUserBitBltSysBmp"           //203
	,"NtGdiGetCharWidthInfo"        //204  
	,"NtUserValidateRect"           //205 
	,"NtUserCloseClipboard"         //206
	,"NtUserOpenClipboard"          //207
	,"NtGdiGetStockObject"          //208 
	,"NtUserSetClipboardData"       //209
	,"NtUserEnableMenuItem"         //210
	,"NtUserAlterWindowStyle"       //211
	,"NtGdiFillRgn"                 //212
	,"NtUserGetWindowPlacement"     //213 
	,"NtGdiModifyWorldTransform"    //214
	,"NtGdiGetFontData"             //215
	,"NtUserGetOpenClipboardWindow" //216
	,"NtUserSetThreadState"         //217
	,"NtGdiOpenDCW"                 //218
	,"NtUserTrackMouseEvent"        //219  
	,"NtGdiGetTransform"            //220
	,"NtUserDestroyMenu"            //221
	,"NtGdiGetBitmapBits"           //222
	,"NtUserConsoleControl"         //223  
	,"NtUserSetActiveWindow"        //224
	,"NtUserSetInformationThread"   //225
	,"NtUserSetWindowPlacement"     //226 
	,"NtUserGetControlColor"        //227
	,"NtGdiSetMetaRgn"              //228
	,"NtGdiSetMiterLimit"           //229
	,"NtGdiSetVirtualResolution"    //230
	,"NtGdiGetRasterizerCaps"       //231
	,"NtUserSetWindowWord"          //232
	,"NtUserGetClipboardFormatName" //233
	,"NtUserRealInternalGetMessage" //234 
	,"NtUserCreateLocalMemHandle"   //235
	,"NtUserAttachThreadInput"      //236
	,"NtGdiCreateHalftonePalette"   //237
	,"NtUserPaintMenuBar"           //238
	,"NtUserSetKeyboardState"       //239
	,"NtGdiCombineTransform"        //240 
	,"NtUserCreateAcceleratorTable" //241
	,"NtUserGetCursorFrameInfo"     //242
	,"NtUserGetAltTabInfo"          //243
	,"NtUserGetCaretBlinkTime"      //244
	,"NtGdiQueryFontAssocInfo"      //245
	,"NtUserProcessConnect"         //246
	,"NtUserEnumDisplayDevices"     //247 
	,"NtUserEmptyClipboard"         //248
	,"NtUserGetClipboardData"       //249
	,"NtUserRemoveMenu"             //250
	,"NtGdiSetBoundsRect"           //251
	,"NtGdiGetBitmapDimension"      //252
	,"NtUserConvertMemHandle"       //253
	,"NtUserDestroyAcceleratorTable"//254 
	,"NtUserGetGUIThreadInfo"       //255
	,"NtGdiCloseFigure"             //256
	,"NtUserSetWindowsHookAW"       //257 
	,"NtUserSetMenuDefaultItem"     //258 
	,"NtUserCheckMenuItem"          //259
	,"NtUserSetWinEventHook"        //260
	,"NtUserUnhookWinEvent"         //261
	,"NtUserLockWindowUpdate"       //262 
	,"NtUserSetSystemMenu"          //263
	,"NtUserThunkedMenuInfo"        //264
	,"NtGdiBeginPath"               //265
	,"NtGdiEndPath"                 //266
	,"NtGdiFillPath"                //267
	,"NtUserCallHwnd"               //268
	,"NtUserDdeInitialize"          //269
	,"NtUserModifyUserStartupInfoFlags"//270 
	,"NtUserCountClipboardFormats"  //271 
	,"NtGdiAddFontMemResourceEx"    //272
	,"NtGdiEqualRgn"                //273
	,"NtGdiGetSystemPaletteUse"     //274
	,"NtGdiRemoveFontMemResourceEx" //275 
	,"NtUserEnumDisplaySettings"    //276
	,"NtUserPaintDesktop"           //277 
	,"NtGdiExtEscape"               //278
	,"NtGdiSetBitmapDimension"      //279 
	,"NtGdiSetFontEnumeration"      //280
	,"NtUserChangeClipboardChain"   //281
	,"NtUserSetClipboardViewer"     //282
	,"NtUserShowWindowAsync"        //283
	,"NtGdiCreateColorSpace"        //284
	,"NtGdiDeleteColorSpace"        //285
	,"NtUserActivateKeyboardLayout" //286 
	,"NtGdiAbortDoc"                //287 
	,"NtGdiAbortPath"               //288
	,"NtGdiAddEmbFontToDC"          //289
	,"NtGdiAddFontResourceW"        //290 
	,"NtGdiAddRemoteFontToDC"       //291
	,"NtGdiAddRemoteMMInstanceToDC" //292
	,"NtGdiAngleArc"                //293
	,"NtGdiAnyLinkedFonts"          //294 
	,"NtGdiArcInternal"             //295
	,"NtGdiBRUSHOBJ_DeleteRbrush"   //296
	,"NtGdiBRUSHOBJ_hGetColorTransform"//297 
	,"NtGdiBRUSHOBJ_pvAllocRbrush"  //298 
	,"NtGdiBRUSHOBJ_pvGetRbrush"    //299
	,"NtGdiBRUSHOBJ_ulGetBrushColor"//300
	,"NtGdiBeginGdiRendering"       //301
	,"NtGdiCLIPOBJ_bEnum"           //302    
	,"NtGdiCLIPOBJ_cEnumStart"      //303
	,"NtGdiCLIPOBJ_ppoGetPath"      //304 
	,"NtGdiCancelDC"                //305
	,"NtGdiChangeGhostFont"         //306
	,"NtGdiCheckBitmapBits"         //307
	,"NtGdiClearBitmapAttributes"   //308
	,"NtGdiClearBrushAttributes"    //309
	,"NtGdiColorCorrectPalette"     //310
	,"NtGdiConfigureOPMProtectedOutput"//311
	,"NtGdiConvertMetafileRect"     //312 
	,"NtGdiCreateBitmapFromDxSurface"//313
	,"NtGdiCreateColorTransform"     //314
	,"NtGdiCreateEllipticRgn"        //315 
	,"NtGdiCreateHatchBrushInternal" //316
	,"NtGdiCreateMetafileDC"         //317
	,"NtGdiCreateOPMProtectedOutputs"//318 
	,"NtGdiCreateRoundRectRgn"       //319
	,"NtGdiCreateServerMetaFile"     //320
	,"NtGdiD3dContextCreate"         //321
	,"NtGdiD3dContextDestroy"        //322
	,"NtGdiD3dContextDestroyAll"     //323 
	,"NtGdiD3dValidateTextureStageState"//324 
	,"NtGdiDDCCIGetCapabilitiesString"//325
	,"NtGdiDDCCIGetCapabilitiesStringLength"//326
	,"NtGdiDDCCIGetTimingReport"     //327
	,"NtGdiDDCCIGetVCPFeature"       //328
	,"NtGdiDDCCISaveCurrentSettings" //329
	,"NtGdiDDCCISetVCPFeature"       //330
	,"NtGdiDdAddAttachedSurface"     //331
	,"NtGdiDdAlphaBlt"               //332
	,"NtGdiDdAttachSurface"          //333
	,"NtGdiDdBeginMoCompFrame"       //334
	,"NtGdiDdCanCreateD3DBuffer"     //335
	,"NtGdiDdColorControl"           //336
	,"NtGdiDdCreateD3DBuffer"        //337
	,"NtGdiDdCreateDirectDrawObject" //338
	,"NtGdiDdCreateFullscreenSprite" //339 
	,"NtGdiDdCreateMoComp"           //340
	,"NtGdiDdDDIAcquireKeyedMutex"   //341
	,"NtGdiDdDDICheckExclusiveOwnership"//342
	,"NtGdiDdDDICheckMonitorPowerState"//343 
	,"NtGdiDdDDICheckOcclusion"      //344
	,"NtGdiDdDDICheckSharedResourceAccess"//345
	,"NtGdiDdDDICheckVidPnExclusiveOwnership"//346
	,"NtGdiDdDDICloseAdapter"        //347
	,"NtGdiDdDDIConfigureSharedResource"//348
	,"NtGdiDdDDICreateAllocation"    //349
	,"NtGdiDdDDICreateContext"       //350
	,"NtGdiDdDDICreateDCFromMemory"  //351
	,"NtGdiDdDDICreateDevice"        //352
	,"NtGdiDdDDICreateKeyedMutex"    //353
	,"NtGdiDdDDICreateOverlay"       //354
	,"NtGdiDdDDICreateSynchronizationObject"//355
	,"NtGdiDdDDIDestroyAllocation"   //356
	,"NtGdiDdDDIDestroyContext"      //357
	,"NtGdiDdDDIDestroyDCFromMemory" //358
	,"NtGdiDdDDIDestroyDevice"       //359
	,"NtGdiDdDDIDestroyKeyedMutex"   //360
	,"NtGdiDdDDIDestroyOverlay"      //361 
	,"NtGdiDdDDIDestroySynchronizationObject"//362
	,"NtGdiDdDDIEscape"				 //363
	,"NtGdiDdDDIFlipOverlay"         //364
	,"NtGdiDdDDIGetContextSchedulingPriority"//365
	,"NtGdiDdDDIGetDeviceState"      //366
	,"NtGdiDdDDIGetDisplayModeList"  //357
	,"NtGdiDdDDIGetMultisampleMethodList"//368
	,"NtGdiDdDDIGetOverlayState"     //369
	,"NtGdiDdDDIGetPresentHistory"   //370
	,"NtGdiDdDDIGetPresentQueueEvent"//371
	,"NtGdiDdDDIGetProcessSchedulingPriorityClass"//372
	,"NtGdiDdDDIGetRuntimeData"      //373
	,"NtGdiDdDDIGetScanLine"         //374
	,"NtGdiDdDDIGetSharedPrimaryHandle"//375
	,"NtGdiDdDDIInvalidateActiveVidPn"//376 
	,"NtGdiDdDDILock"                //377
	,"NtGdiDdDDIOpenAdapterFromDeviceName"//378
	,"NtGdiDdDDIOpenAdapterFromHdc"  //379
	,"NtGdiDdDDIOpenKeyedMutex"      //380
	,"NtGdiDdDDIOpenResource"        //381
	,"NtGdiDdDDIOpenSynchronizationObject"//382
	,"NtGdiDdDDIPollDisplayChildren" //383
	,"NtGdiDdDDIPresent"             //384
	,"NtGdiDdDDIQueryAdapterInfo"    //385 
	,"NtGdiDdDDIQueryAllocationResidency"//386
	,"NtGdiDdDDIQueryResourceInfo"    //387
	,"NtGdiDdDDIQueryStatistics"      //388
	,"NtGdiDdDDIReleaseKeyedMutex"	  //389
	,"NtGdiDdDDIReleaseProcessVidPnSourceOwners"//390
	,"NtGdiDdDDIRender"		          //391
	,"NtGdiDdDDISetAllocationPriority"//392
	,"NtGdiDdDDISetContextSchedulingPriority"//393
	,"NtGdiDdDDISetDisplayMode"		  //394
	,"NtGdiDdDDISetDisplayPrivateDriverFormat"//395
	,"NtGdiDdDDISetGammaRamp"		  //396
	,"NtGdiDdDDISetProcessSchedulingPriorityClass"//397
	,"NtGdiDdDDISetQueuedLimit"		  //398
	,"NtGdiDdDDISetVidPnSourceOwner"  //399
	,"NtGdiDdDDISharedPrimaryLockNotification"//400
	,"NtGdiDdDDISharedPrimaryUnLockNotification"//401
	,"NtGdiDdDDISignalSynchronizationObject"//402
	,"NtGdiDdDDIUnlock"		         //403
	,"NtGdiDdDDIUpdateOverlay"		 //404
	,"NtGdiDdDDIWaitForIdle"		 //405
	,"NtGdiDdDDIWaitForSynchronizationObject"//406
	,"NtGdiDdDDIWaitForVerticalBlankEvent"//407
	,"NtGdiDdDeleteDirectDrawObject" //408
	,"NtGdiDdDestroyD3DBuffer"		 //409
	,"NtGdiDdDestroyFullscreenSprite"//410
	,"NtGdiDdDestroyMoComp"		     //411
	,"NtGdiDdEndMoCompFrame"		 //412
	,"NtGdiDdFlip"		             //413
	,"NtGdiDdFlipToGDISurface"		 //414
	,"NtGdiDdGetAvailDriverMemory"	 //415
	,"NtGdiDdGetBltStatus"		     //416
	,"NtGdiDdGetDC"		             //417
	,"NtGdiDdGetDriverInfo"		     //418
	,"NtGdiDdGetDriverState"		 //419
	,"NtGdiDdGetDxHandle"		     //420
	,"NtGdiDdGetFlipStatus"		     //421
	,"NtGdiDdGetInternalMoCompInfo"	 //422
	,"NtGdiDdGetMoCompBuffInfo"		 //423
	,"NtGdiDdGetMoCompFormats"		 //424
	,"NtGdiDdGetMoCompGuids"		 //425
	,"NtGdiDdGetScanLine"		     //426
	,"NtGdiDdLock"		             //427
	,"NtGdiDdNotifyFullscreenSpriteUpdate"//428
	,"NtGdiDdQueryDirectDrawObject"	 //429
	,"NtGdiDdQueryMoCompStatus"		 //430
	,"NtGdiDdQueryVisRgnUniqueness"	 //431
	,"NtGdiDdReenableDirectDrawObject"//432
	,"NtGdiDdReleaseDC"		         //433
	,"NtGdiDdRenderMoComp"			 //434
	,"NtGdiDdSetColorKey"			 //435
	,"NtGdiDdSetExclusiveMode"		 //436
	,"NtGdiDdSetGammaRamp"			 //437
	,"NtGdiDdSetOverlayPosition"	 //438
	,"NtGdiDdUnattachSurface"		 //439
	,"NtGdiDdUnlock"			     //440
	,"NtGdiDdUpdateOverlay"			 //441
	,"NtGdiDdWaitForVerticalBlank"	 //442
	,"NtGdiDeleteColorTransform"	 //443
	,"NtGdiDescribePixelFormat"		 //444
	,"NtGdiDestroyOPMProtectedOutput"//445
	,"NtGdiDestroyPhysicalMonitor"	 //446
	,"NtGdiDoBanding"				 //447
	,"NtGdiDrawEscape"				 //448
	,"NtGdiDvpAcquireNotification"	 //449
	,"NtGdiDvpCanCreateVideoPort"	 //450
	,"NtGdiDvpColorControl"			 //451
	,"NtGdiDvpCreateVideoPort"		 //452
	,"NtGdiDvpDestroyVideoPort"		 //453
	,"NtGdiDvpFlipVideoPort"		 //454
	,"NtGdiDvpGetVideoPortBandwidth" //455
	,"NtGdiDvpGetVideoPortConnectInfo"//456
	,"NtGdiDvpGetVideoPortField"	 //457
	,"NtGdiDvpGetVideoPortFlipStatus"//458
	,"NtGdiDvpGetVideoPortInputFormats"//459
	,"NtGdiDvpGetVideoPortLine"		 //460
	,"NtGdiDvpGetVideoPortOutputFormats"//461
	,"NtGdiDvpGetVideoSignalStatus"	 //462
	,"NtGdiDvpReleaseNotification"	 //463
	,"NtGdiDvpUpdateVideoPort"		 //464
	,"NtGdiDvpWaitForVideoPortSync"	 //465
	,"NtGdiDxgGenericThunk"		     //466
	,"NtGdiEllipse"					 //467
	,"NtGdiEnableEudc"				 //468
	,"NtGdiEndDoc"				     //469
	,"NtGdiEndGdiRendering"			 //470
	,"NtGdiEndPage"					 //471
	,"NtGdiEngAlphaBlend"			 //472
	,"NtGdiEngAssociateSurface"		 //473
	,"NtGdiEngBitBlt"				 //474
	,"NtGdiEngCheckAbort"		     //475
	,"NtGdiEngComputeGlyphSet"		 //476
	,"NtGdiEngCopyBits"				 //477
	,"NtGdiEngCreateBitmap"			 //478
	,"NtGdiEngCreateClip"			 //479
	,"NtGdiEngCreateDeviceBitmap"	 //480
	,"NtGdiEngCreateDeviceSurface"	 //481
	,"NtGdiEngCreatePalette"		 //482
	,"NtGdiEngDeleteClip"			 //483
	,"NtGdiEngDeletePalette"		 //484
	,"NtGdiEngDeletePath"			 //485
	,"NtGdiEngDeleteSurface"		 //486
	,"NtGdiEngEraseSurface"			 //487
	,"NtGdiEngFillPath"				 //488
	,"NtGdiEngGradientFill"			 //489
	,"NtGdiEngLineTo"				 //490
	,"NtGdiEngLockSurface"			 //491
	,"NtGdiEngMarkBandingSurface"	 //492
	,"NtGdiEngPaint"				 //493
	,"NtGdiEngPlgBlt"				 //494
	,"NtGdiEngStretchBlt"			 //495
	,"NtGdiEngStretchBltROP"		 //496
	,"NtGdiEngStrokeAndFillPath"	 //497
	,"NtGdiEngStrokePath"			 //498
	,"NtGdiEngTextOut"				 //499
	,"NtGdiEngTransparentBlt"		 //500
	,"NtGdiEngUnlockSurface"		 //501
	,"NtGdiEnumFonts"				 //502
	,"NtGdiEnumObjects"				 //503
	,"NtGdiEudcLoadUnloadLink"		 //504
	,"NtGdiExtFloodFill"			 //505
	,"NtGdiFONTOBJ_cGetAllGlyphHandles"	//506
	,"NtGdiFONTOBJ_cGetGlyphs"		 //507
	,"NtGdiFONTOBJ_pQueryGlyphAttrs" //508
	,"NtGdiFONTOBJ_pfdg"			 //509
	,"NtGdiFONTOBJ_pifi"			 //510
	,"NtGdiFONTOBJ_pvTrueTypeFontFile"//511
	,"NtGdiFONTOBJ_pxoGetXform"		 //512
	,"NtGdiFONTOBJ_vGetInfo"		 //513
	,"NtGdiFlattenPath"				 //514
	,"NtGdiFontIsLinked"			 //515
	,"NtGdiForceUFIMapping"		     //516
	,"NtGdiFrameRgn"		         //517
	,"NtGdiFullscreenControl"		 //518
	,"NtGdiGetBoundsRect"		     //519
	,"NtGdiGetCOPPCompatibleOPMInformation"//520
	,"NtGdiGetCertificate"			 //521
	,"NtGdiGetCertificateSize"		 //522
	,"NtGdiGetCharABCWidthsW"		 //523
	,"NtGdiGetCharacterPlacementW"	 //524
	,"NtGdiGetColorAdjustment"		 //525
	,"NtGdiGetColorSpaceforBitmap"	 //526
	,"NtGdiGetDeviceCaps"			 //527
	,"NtGdiGetDeviceCapsAll"		 //528
	,"NtGdiGetDeviceGammaRamp"		 //529
	,"NtGdiGetDeviceWidth"			 //530
	,"NtGdiGetDhpdev"				 //531
	,"NtGdiGetETM"					 //532
	,"NtGdiGetEmbUFI"				 //533
	,"NtGdiGetEmbedFonts"			 //534
	,"NtGdiGetEudcTimeStampEx"		 //535
	,"NtGdiGetFontFileData"			 //536
	,"NtGdiGetFontFileInfo"			 //537
	,"NtGdiGetFontResourceInfoInternalW"//538
	,"NtGdiGetFontUnicodeRanges"	 //539
	,"NtGdiGetGlyphIndicesW"		 //540
	,"NtGdiGetGlyphIndicesWInternal" //541
	,"NtGdiGetGlyphOutline"			 //542
	,"NtGdiGetKerningPairs"			 //543
	,"NtGdiGetLinkedUFIs"			 //544
	,"NtGdiGetMiterLimit"			 //545
	,"NtGdiGetMonitorID"			 //546
	,"NtGdiGetNumberOfPhysicalMonitors"	//547
	,"NtGdiGetOPMInformation"		 //548
	,"NtGdiGetOPMRandomNumber"		 //549
	,"NtGdiGetObjectBitmapHandle"	 //550
	,"NtGdiGetPath"					 //551
	,"NtGdiGetPerBandInfo"			 //552
	,"NtGdiGetPhysicalMonitorDescription"//553
	,"NtGdiGetPhysicalMonitors"		 //554
	,"NtGdiGetRealizationInfo"		 //555
	,"NtGdiGetServerMetaFileBits"	 //556
	,"DxgStubAlphaBlt"				 //557
	,"NtGdiGetStats"				 //558
	,"NtGdiGetStringBitmapW"		 //559
	,"NtGdiGetSuggestedOPMProtectedOutputArraySize"//560
	,"NtGdiGetTextExtentExW"		 //561
	,"NtGdiGetUFI"					 //562
	,"NtGdiGetUFIPathname"			 //563
	,"NtGdiGradientFill"			 //564
	,"NtGdiHLSurfGetInformation"	 //565
	,"NtGdiHLSurfSetInformation"	 //566
	,"NtGdiHT_Get8BPPFormatPalette"	 //567
	,"NtGdiHT_Get8BPPMaskPalette"	 //568
	,"NtGdiIcmBrushInfo"			 //569
	,"EngRestoreFloatingPointState"	 //570
	,"NtGdiInitSpool"				 //571
	,"NtGdiMakeFontDir"				 //572
	,"NtGdiMakeInfoDC"				 //573
	,"NtGdiMakeObjectUnXferable"	 //574
	,"NtGdiMakeObjectXferable"		 //575
	,"NtGdiMirrorWindowOrg"			 //576
	,"NtGdiMonoBitmap"				 //577
	,"NtGdiMoveTo"					 //578
	,"NtGdiOffsetClipRgn"			 //579
	,"NtGdiPATHOBJ_bEnum"			 //580
	,"NtGdiPATHOBJ_bEnumClipLines"	 //581
	,"NtGdiPATHOBJ_vEnumStart"		 //582
	,"NtGdiPATHOBJ_vEnumStartClipLines"//583
	,"NtGdiPATHOBJ_vGetBounds"		 //584
	,"NtGdiPathToRegion"			 //585
	,"NtGdiPlgBlt"					 //586
	,"NtGdiPolyDraw"				 //587
	,"NtGdiPolyTextOutW"			 //588
	,"NtGdiPtInRegion"				 //589
	,"NtGdiPtVisible"				 //590
	,"NtGdiQueryFonts"				 //591
	,"NtGdiRemoveFontResourceW"		 //592
	,"NtGdiRemoveMergeFont"			 //593
	,"NtGdiResetDC"					 //594
	,"NtGdiResizePalette"			 //595
	,"NtGdiRoundRect"				 //596
	,"NtGdiSTROBJ_bEnum"			 //597
	,"NtGdiSTROBJ_bEnumPositionsOnly"//598
	,"NtGdiSTROBJ_bGetAdvanceWidths" //599
	,"NtGdiSTROBJ_dwGetCodePage"	 //600
	,"NtGdiSTROBJ_vEnumStart"		 //601
	,"NtGdiScaleViewportExtEx"		 //602
	,"NtGdiScaleWindowExtEx"		 //603
	,"NtGdiSelectBrush"				 //604
	,"NtGdiSelectClipPath"			 //605
	,"NtGdiSelectPen"				 //606
	,"NtGdiSetBitmapAttributes"		 //607
	,"NtGdiSetBrushAttributes"		 //608
	,"NtGdiSetColorAdjustment"		 //609
	,"NtGdiSetColorSpace"			 //610
	,"NtGdiSetDeviceGammaRamp"		 //611
	,"NtGdiSetFontXform"			 //612
	,"NtGdiSetIcmMode"				 //613
	,"NtGdiSetLinkedUFIs"			 //614
	,"NtGdiSetMagicColors"			 //615
	,"NtGdiSetOPMSigningKeyAndSequenceNumbers"//616
	,"NtGdiSetPUMPDOBJ"				 //617
	,"NtGdiSetPixelFormat"			 //618
	,"NtGdiSetRectRgn"				 //619
	,"NtGdiSetSizeDevice"			 //620
	,"NtGdiSetSystemPaletteUse"		 //621
	,"NtGdiSetTextJustification"	 //622
	,"NtGdiSfmGetNotificationTokens" //623
	,"NtGdiStartDoc"				 //624
	,"NtGdiStartPage"				 //625
	,"NtGdiStrokeAndFillPath"		 //626
	,"NtGdiStrokePath"				 //627
	,"NtGdiSwapBuffers"				 //628
	,"NtGdiTransparentBlt"			 //629
	,"NtGdiUMPDEngFreeUserMem"		 //630
	,"DxgStubAlphaBlt"				 //631
	,"EngRestoreFloatingPointState"	 //632
	,"NtGdiUpdateColors"			 //633
	,"NtGdiUpdateTransform"			 //634
	,"NtGdiWidenPath"				 //635
	,"NtGdiXFORMOBJ_bApplyXform"	 //636
	,"NtGdiXFORMOBJ_iGetXform"		 //637
	,"NtGdiXLATEOBJ_cGetPalette"	 //638
	,"NtGdiXLATEOBJ_hGetColorTransform"//639
	,"NtGdiXLATEOBJ_iXlate"			 //640
	,"NtUserAddClipboardFormatListener"//641
	,"NtUserAssociateInputContext"	 //642
	,"NtUserBlockInput"				 //643
	,"NtUserBuildHimcList"			 //644
	,"NtUserBuildPropList"			 //645
	,"NtUserCalculatePopupWindowPosition"//646
	,"NtUserCallHwndOpt"			 //647
	,"NtUserChangeDisplaySettings"	 //648
	,"NtUserChangeWindowMessageFilterEx"//649
	,"NtUserCheckAccessForIntegrityLevel"//650
	,"NtUserCheckDesktopByThreadId"	 //651
	,"NtUserCheckWindowThreadDesktop"//652
	,"NtUserChildWindowFromPointEx"	 //653
	,"NtUserClipCursor"				 //654
	,"NtUserCreateDesktopEx"	     //655
	,"NtUserCreateInputContext"		 //656
	,"NtUserCreateWindowStation"	 //657
	,"NtUserCtxDisplayIOCtl"		 //658
	,"NtUserDestroyInputContext"	 //659
	,"NtUserDisableThreadIme"		 //660
	,"NtUserDisplayConfigGetDeviceInfo"//661
	,"NtUserDisplayConfigSetDeviceInfo"//662
	,"NtUserDoSoundConnect"			 //663
	,"NtUserDoSoundDisconnect"		 //664
	,"NtUserDragDetect"				 //665
	,"NtUserDragObject"				 //666
	,"NtUserDrawAnimatedRects"		 //667
	,"NtUserDrawCaption"			 //668
	,"NtUserDrawCaptionTemp"		 //669
	,"NtUserDrawMenuBarTemp"		 //670
	,"NtUserDwmStartRedirection"	 //671
	,"NtUserDwmStopRedirection"		 //672
	,"NtUserEndMenu"				 //673
	,"NtUserEndTouchOperation"		 //674
	,"NtUserEvent"					 //675
	,"NtUserFlashWindowEx"		     //676
	,"NtUserFrostCrashedWindow"		 //677
	,"NtUserGetAppImeLevel"			 //678
	,"NtUserGetCaretPos"			 //679
	,"NtUserGetClipCursor"			 //680
	,"NtUserGetClipboardViewer"		 //681
	,"NtUserGetComboBoxInfo"		 //682
	,"NtUserGetCursorInfo"			 //683
	,"NtUserGetDisplayConfigBufferSizes"//684
	,"NtUserGetGestureConfig"		 //685
	,"NtUserGetGestureExtArgs"		 //686
	,"NtUserGetGestureInfo"			 //687
	,"NtUserGetGuiResources"		 //688
	,"NtUserGetImeHotKey"			 //689
	,"NtUserGetImeInfoEx"			 //690
	,"NtUserGetInputLocaleInfo"		 //691
	,"NtUserGetInternalWindowPos"	 //692
	,"NtUserGetKeyNameText"			 //693
	,"NtUserGetKeyboardLayoutName"	 //694
	,"NtUserGetLayeredWindowAttributes"//695
	,"NtUserGetListBoxInfo"			 //696
	,"NtUserGetMenuIndex"			 //697
	,"NtUserGetMenuItemRect"		 //698
	,"NtUserGetMouseMovePointsEx"	 //699
	,"NtUserGetPriorityClipboardFormat"//700
	,"NtUserGetRawInputBuffer"		 //701
	,"NtUserGetRawInputData"		 //702
	,"NtUserGetRawInputDeviceInfo"	 //703
	,"NtUserGetRawInputDeviceList"	 //704
	,"NtUserGetRegisteredRawInputDevices"//705
	,"NtUserGetTopLevelWindow"		 //706
	,"NtUserGetTouchInputInfo"		 //707
	,"NtUserGetUpdatedClipboardFormats"//708
	,"NtUserGetWOWClass"			 //709
	,"NtUserGetWindowCompositionAttribute"//710
	,"NtUserGetWindowCompositionInfo"//711
	,"NtUserGetWindowDisplayAffinity"//712
	,"NtUserGetWindowMinimizeRect"	 //713
	,"NtUserGetWindowRgnEx"			 //714
	,"NtUserGhostWindowFromHungWindow"//715
	,"NtUserHardErrorControl"		 //716
	,"NtUserHiliteMenuItem"			 //717
	,"NtUserHungWindowFromGhostWindow"//718
	,"NtUserHwndQueryRedirectionInfo"//719
	,"NtUserHwndSetRedirectionInfo"	 //720
	,"NtUserImpersonateDdeClientWindow"//721
	,"NtUserInitTask"				 //722
	,"NtUserInitialize"			     //723
	,"NtUserInitializeClientPfnArrays"//724
	,"NtUserInjectGesture"			 //725
	,"NtUserInternalGetWindowIcon"	 //726
	,"NtUserIsTopLevelWindow"		 //727
	,"NtUserIsTouchWindow"			 //728
	,"NtUserLoadKeyboardLayoutEx"	 //729
	,"NtUserLockWindowStation"		 //730
	,"NtUserLockWorkStation"		 //731
	,"NtUserLogicalToPhysicalPoint"	 //732
	,"NtUserMNDragLeave"			 //733
	,"NtUserMNDragOver"				 //734
	,"NtUserMagControl"				 //735
	,"NtUserMagGetContextInformation"//736
	,"NtUserMagSetContextInformation"//737
	,"NtUserManageGestureHandlerWindow"//738
	,"NtUserMenuItemFromPoint"		 //739
	,"NtUserMinMaximize"			 //740
	,"NtUserModifyWindowTouchCapability"//741
	,"NtUserNotifyIMEStatus"		 //742
	,"NtUserOpenInputDesktop"		 //743
	,"NtUserOpenThreadDesktop"		 //744
	,"NtUserPaintMonitor"			 //745
	,"NtUserPhysicalToLogicalPoint"	 //746
	,"NtUserPrintWindow"			 //747
	,"NtUserQueryDisplayConfig"		 //748
	,"NtUserQueryInformationThread"	 //749
	,"NtUserQueryInputContext"		 //750
	,"NtUserQuerySendMessage"		 //751
	,"NtUserRealChildWindowFromPoint"//752
	,"NtUserRealWaitMessageEx"		 //753
	,"NtUserRegisterErrorReportingDialog"//754
	,"NtUserRegisterHotKey"			 //755
	,"NtUserRegisterRawInputDevices" //756
	,"NtUserRegisterServicesProcess" //757
	,"NtUserRegisterSessionPort"	 //758
	,"NtUserRegisterTasklist"		 //759
	,"NtUserRegisterUserApiHook"	 //760
	,"NtUserRemoteConnect"			 //761
	,"NtUserRemoteRedrawRectangle"	 //762
	,"NtUserRemoteRedrawScreen"		 //763
	,"NtUserRemoteStopScreenUpdates" //764
	,"NtUserRemoveClipboardFormatListener"//765
	,"NtUserResolveDesktopForWOW"	 //766
	,"NtUserSendTouchInput"			 //767
	,"NtUserSetAppImeLevel"			 //768
	,"NtUserSetChildWindowNoActivate"//769
	,"NtUserSetClassWord"			 //770
	,"NtUserSetCursorContents"		 //771
	,"NtUserSetDisplayConfig"		 //772
	,"NtUserSetGestureConfig"		 //773
	,"NtUserSetImeHotKey"			 //774
	,"NtUserSetImeInfoEx"			 //775
	,"NtUserSetImeOwnerWindow"		 //776
	,"NtUserSetInternalWindowPos"	 //777
	,"NtUserSetLayeredWindowAttributes"	//778
	,"NtUserSetMenu"				 //779
	,"NtUserSetMenuContextHelpId"	 //780
	,"NtUserSetMenuFlagRtoL"		 //781
	,"NtUserSetMirrorRendering"		 //782
	,"NtUserSetObjectInformation"	 //783
	,"NtUserSetProcessDPIAware"		 //784
	,"NtUserSetShellWindowEx"		 //785
	,"NtUserSetSysColors"			 //786
	,"NtUserSetSystemCursor"		 //787
	,"NtUserSetSystemTimer"			 //788
	,"NtUserSetThreadLayoutHandles"	 //789
	,"NtUserSetWindowCompositionAttribute"//790
	,"NtUserSetWindowDisplayAffinity"//791
	,"NtUserSetWindowRgnEx"			 //792
	,"NtUserSetWindowStationUser"	 //793
	,"NtUserSfmDestroyLogicalSurfaceBinding"//794
	,"NtUserSfmDxBindSwapChain"		 //795
	,"NtUserSfmDxGetSwapChainStats"	 //796
	,"NtUserSfmDxOpenSwapChain"		 //797
	,"NtUserSfmDxQuerySwapChainBindingStatus"//798
	,"NtUserSfmDxReleaseSwapChain"	 //799
	,"NtUserSfmDxReportPendingBindingsToDwm"//800
	,"NtUserSfmDxSetSwapChainBindingStatus"//801
	,"NtUserSfmDxSetSwapChainStats"	 //802
	,"NtUserSfmGetLogicalSurfaceBinding"//803
	,"NtUserShowSystemCursor"		 //804
	,"NtUserSoundSentry"			 //805
	,"NtUserSwitchDesktop"			 //806
	,"NtUserTestForInteractiveUser"	 //807
	,"NtUserTrackPopupMenuEx"		 //808
	,"NtUserUnloadKeyboardLayout"	 //809
	,"NtUserUnlockWindowStation"	 //810
	,"NtUserUnregisterHotKey"		 //811
	,"NtUserUnregisterSessionPort"	 //812
	,"NtUserUnregisterUserApiHook"	 //813
	,"NtUserUpdateInputContext"		 //814
	,"NtUserUpdateInstance"			 //815
	,"NtUserUpdateLayeredWindow"	 //816
	,"NtUserUpdatePerUserSystemParameters"//817
	,"NtUserUpdateWindowTransform"	 //818
	,"NtUserUserHandleGrantAccess"	 //819
	,"NtUserValidateHandleSecure"	 //820
	,"NtUserWaitForInputIdle"		 //821
	,"NtUserWaitForMsgAndEvent"		 //822
	,"NtUserWindowFromPhysicalPoint" //823
	,"NtUserYieldTask"				 //824
	,"NtUserSetClassLongPtr"		 //825
	,"NtUserSetWindowLongPtr"		 //826
};
Check Kernel EAT Hook 

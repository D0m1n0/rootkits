use PsSetLoadImageNotifyRoutine to monitor DLL load
when loading scan IAT

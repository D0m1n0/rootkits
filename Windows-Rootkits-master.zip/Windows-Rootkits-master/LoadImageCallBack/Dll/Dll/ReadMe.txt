Dll File to popup a messagebox when loaded

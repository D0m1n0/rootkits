Inject Demo to inject dll to a target process

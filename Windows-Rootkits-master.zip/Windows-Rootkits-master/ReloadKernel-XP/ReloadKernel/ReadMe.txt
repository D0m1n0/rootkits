Reload Kernel in Windows XP 

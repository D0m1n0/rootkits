Load ntoskrnl.exe to replace ServiceDescriptorTable

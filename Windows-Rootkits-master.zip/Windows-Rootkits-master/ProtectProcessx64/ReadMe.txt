Protect Process in Windows 7 by ObRegisterCallbacks

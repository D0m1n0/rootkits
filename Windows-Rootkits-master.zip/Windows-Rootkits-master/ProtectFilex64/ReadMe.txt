Protect File in Windows 7 by ObRegisterCallbacks

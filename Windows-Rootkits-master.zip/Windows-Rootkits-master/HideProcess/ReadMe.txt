Break in the process active list to hide process 
Can hide process in the Windows Task Manager in Windows XP/7

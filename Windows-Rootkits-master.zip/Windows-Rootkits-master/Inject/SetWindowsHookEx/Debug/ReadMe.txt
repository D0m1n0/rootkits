Inject DLL by SetWindowsHookEx

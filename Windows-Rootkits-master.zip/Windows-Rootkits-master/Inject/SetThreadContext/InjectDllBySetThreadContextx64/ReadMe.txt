Inject 32 bit process by change eip to execute the shellcode which will load a dll
Inject 64 bit process by change rip to execute the shellcode which will load a dll

http://www.cnblogs.com/aliflycoris/p/5432621.html

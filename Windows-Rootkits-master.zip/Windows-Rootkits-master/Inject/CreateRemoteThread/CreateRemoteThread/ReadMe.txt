32 bit process Inject The dll to 32 bit process
64 bit process Inject The dll to 64 bit process
sometimes you maybe fail to inject because cann't openprocess successful
and many safe software will protect it avoiding you to inject
